# first project
 This is my first project in django. Its a one page site.
